# Ekşi Sözlük Normalleştirici

- Firefox: https://addons.mozilla.org/tr/firefox/addon/eksinormallestirici/
- Chrome: https://chrome.google.com/webstore/detail/eksi-normallestirici/kecgggbhlngbgalldonjhppjolpohlma
